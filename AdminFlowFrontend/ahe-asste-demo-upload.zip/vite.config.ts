import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],

  server: {
    proxy: {
      "/azurite": {
        target: "http://127.0.0.1:10000",
        changeOrigin: true,

        rewrite: (path) => path.replace(/^\/azurite/, ""),
      },
    },
  },
});
