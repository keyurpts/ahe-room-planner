// import {
//   ChangeEvent,
//   FormEvent,
//   useEffect,
//   useState,
// } from "react";
// import "./App.css";

// const API_BASE_URL = "http://localhost:5217";

// type CategoryResponse = {
//   id?: string;
//   categoryId: string;
//   categoryName: string;
//   description?: string;
// };

// type RegionResponse = {
//   id?: string;
//   regionId: string;
//   name: string;
//   code?: string;
// };

// type ModelResponse = {
//   id: string;
//   modelId: string;
//   modelName: string;
//   categoryId: string;
//   modelPath?: string;
// };

// type UploadUrlResponse = {
//   modelId: string;
//   blobPath: string;
//   uploadUrl: string;
//   expiresAt: string;
// };

// function App() {
//   const [accessToken, setAccessToken] = useState("");

//   // ============================================================
//   // CATEGORY STATE
//   // ============================================================

//   const [categoryName, setCategoryName] = useState("");
//   const [categoryDescription, setCategoryDescription] =
//     useState("");

//   const [createdCategory, setCreatedCategory] =
//     useState<CategoryResponse | null>(null);

//   const [categories, setCategories] = useState<
//     CategoryResponse[]
//   >([]);

//   const [selectedCategoryId, setSelectedCategoryId] =
//     useState("");

//   // ============================================================
//   // REGION STATE
//   // ============================================================

//   const [regions, setRegions] = useState<
//     RegionResponse[]
//   >([]);

//   const [selectedRegionId, setSelectedRegionId] =
//     useState("");

//   // ============================================================
//   // MODEL STATE
//   // ============================================================

//   const [modelCode, setModelCode] = useState("");
//   const [modelName, setModelName] = useState("");
//   const [modelMetadata, setModelMetadata] =
//     useState("");

//   const [itemNumber, setItemNumber] = useState("");
//   const [price, setPrice] = useState("");
//   const [description, setDescription] =
//     useState("");

//   const [assetFile, setAssetFile] =
//     useState<File | null>(null);

//   // ============================================================
//   // RESULT STATE
//   // ============================================================

//   const [createdModel, setCreatedModel] =
//     useState<ModelResponse | null>(null);

//   const [uploadInfo, setUploadInfo] =
//     useState<UploadUrlResponse | null>(null);

//   const [status, setStatus] = useState("");

//   const [isCreatingCategory, setIsCreatingCategory] =
//     useState(false);

//   const [isCreatingModel, setIsCreatingModel] =
//     useState(false);

//   // ============================================================
//   // GENERIC API REQUEST
//   // ============================================================

//   // async function apiRequest<T>(
//   //   endpoint: string,
//   //   options: RequestInit = {}
//   // ): Promise<T> {
//   //   const response = await fetch(
//   //     `${API_BASE_URL}${endpoint}`,
//   //     {
//   //       ...options,
//   //       headers: {
//   //         ...(accessToken
//   //           ? {
//   //               Authorization: `Bearer ${accessToken}`,
//   //             }
//   //           : {}),
//   //         ...(options.headers || {}),
//   //       },
//   //     }
//   //   );

//   //   if (!response.ok) {
//   //     const errorText =
//   //       await response.text();

//   //     throw new Error(
//   //       `${response.status} ${response.statusText}: ${errorText}`
//   //     );
//   //   }

//   //   return response.json();
//   // }

//   async function apiRequest<T>(
//     endpoint: string,
//     options: RequestInit = {}
//   ): Promise<T> {
//     const url = `${API_BASE_URL}${endpoint}`;

//     console.log("API Request:", options.method || "GET", url);

//     const response = await fetch(url, {
//       ...options,
//       headers: {
//         ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
//         ...(options.headers || {}),
//       },
//     });

//     console.log("API Response:", response.status, response.statusText, url);

//     if (!response.ok) {
//       const errorText = await response.text();

//       console.error("API Error:", {
//         url,
//         status: response.status,
//         statusText: response.statusText,
//         response: errorText,
//       });

//       throw new Error(
//         `${response.status} ${response.statusText}: ${errorText}`
//       );
//     }

//     return response.json();
//   }

//   // ============================================================
//   // LOAD CATEGORIES
//   // ============================================================

//   async function loadCategories() {
//     try {
//       const response =
//         await apiRequest<CategoryResponse[]>(
//           "/api/Categories",
//           {
//             method: "GET",
//           }
//         );

//       setCategories(response);

//       console.log(
//         "Categories loaded:",
//         response
//       );
//     } catch (error) {
//       console.error(
//         "Unable to load categories:",
//         error
//       );

//       setStatus(
//         error instanceof Error
//           ? error.message
//           : "Unable to load categories."
//       );
//     }
//   }

//   // ============================================================
//   // LOAD REGIONS
//   // ============================================================

//   async function loadRegions() {
//     try {
//       const response =
//         await apiRequest<RegionResponse[]>(
//           "/api/Regions",
//           {
//             method: "GET",
//           }
//         );

//       setRegions(response);

//       console.log(
//         "Regions loaded:",
//         response
//       );
//     } catch (error) {
//       console.error(
//         "Unable to load regions:",
//         error
//       );

//       setStatus(
//         error instanceof Error
//           ? error.message
//           : "Unable to load regions."
//       );
//     }
//   }

//   // ============================================================
//   // LOAD CATEGORIES AND REGIONS WHEN JWT IS AVAILABLE
//   // ============================================================

//   useEffect(() => {
//     if (!accessToken.trim()) {
//       setCategories([]);
//       setRegions([]);
//       setSelectedCategoryId("");
//       setSelectedRegionId("");
//       return;
//     }

//     loadCategories();
//     loadRegions();
//   }, [accessToken]);

//   // ============================================================
//   // CREATE CATEGORY
//   // ============================================================

//   async function handleCreateCategory(
//     event: FormEvent<HTMLFormElement>
//   ) {
//     event.preventDefault();

//     if (!accessToken.trim()) {
//       setStatus(
//         "Please enter your JWT access token."
//       );
//       return;
//     }

//     setIsCreatingCategory(true);
//     setStatus("");

//     try {
//       const response =
//         await apiRequest<CategoryResponse>(
//           "/api/Categories",
//           {
//             method: "POST",
//             headers: {
//               "Content-Type": "application/json",
//             },
//             body: JSON.stringify({
//               categoryId:
//                 crypto.randomUUID(),

//               categoryName:
//                 categoryName.trim(),

//               description:
//                 categoryDescription.trim(),
//             }),
//           }
//         );

//       setCreatedCategory(response);

//       // Refresh category dropdown after
//       // successfully creating a category.
//       await loadCategories();

//       setStatus(
//         "Category created successfully."
//       );
//     } catch (error) {
//       console.error(
//         "Create category error:",
//         error
//       );

//       setStatus(
//         error instanceof Error
//           ? error.message
//           : "Unable to create category."
//       );
//     } finally {
//       setIsCreatingCategory(false);
//     }
//   }

//   // ============================================================
//   // CREATE MODEL AND UPLOAD ASSET
//   // ============================================================

//   async function handleCreateModelAndUpload(
//     event: FormEvent<HTMLFormElement>
//   ) {
//     event.preventDefault();

//     if (!accessToken.trim()) {
//       setStatus(
//         "Please enter your JWT access token."
//       );
//       return;
//     }

//     if (!selectedCategoryId) {
//       setStatus(
//         "Please select a category."
//       );
//       return;
//     }

//     if (!selectedRegionId) {
//       setStatus(
//         "Please select a region."
//       );
//       return;
//     }

//     if (!assetFile) {
//       setStatus(
//         "Please select a GLB asset."
//       );
//       return;
//     }

//     if (!modelCode.trim()) {
//       setStatus(
//         "Please enter a model code."
//       );
//       return;
//     }

//     if (!modelName.trim()) {
//       setStatus(
//         "Please enter a model name."
//       );
//       return;
//     }

//     if (!modelMetadata.trim()) {
//       setStatus(
//         "Please enter model metadata."
//       );
//       return;
//     }

//     if (!itemNumber.trim()) {
//       setStatus(
//         "Please enter an item number."
//       );
//       return;
//     }

//     if (!price.trim()) {
//       setStatus(
//         "Please enter a price."
//       );
//       return;
//     }

//     if (!description.trim()) {
//       setStatus(
//         "Please enter a description."
//       );
//       return;
//     }

//     const numericPrice =
//       Number(price);

//     if (
//       Number.isNaN(numericPrice) ||
//       numericPrice < 0
//     ) {
//       setStatus(
//         "Please enter a valid price."
//       );
//       return;
//     }

//     setIsCreatingModel(true);
//     setStatus("");
//     setCreatedModel(null);
//     setUploadInfo(null);

//     try {
//       // --------------------------------------------------------
//       // 1. CREATE MODEL
//       // --------------------------------------------------------

//       setStatus(
//         "Creating model entry..."
//       );

//       const modelResponse =
//         await apiRequest<ModelResponse>(
//           "/api/Models",
//           {
//             method: "POST",
//             headers: {
//               "Content-Type":
//                 "application/json",
//             },

//             body: JSON.stringify({
//               modelId:
//                 modelCode.trim(),

//               categoryId:
//                 selectedCategoryId,

//               modelName:
//                 modelName.trim(),

//               // This will be updated/handled
//               // through the asset upload flow.
//               modelPath:
//                 "pending",

//               modelThumbnailPath:
//                 "",

//               modelMetadata:
//                 modelMetadata.trim(),

//               regions: [
//                 {
//                   regionId:
//                     selectedRegionId,

//                   itemNumber:
//                     itemNumber.trim(),

//                   price:
//                     numericPrice,

//                   description:
//                     description.trim(),
//                 },
//               ],
//             }),
//           }
//         );

//       setCreatedModel(
//         modelResponse
//       );

//       // --------------------------------------------------------
//       // 2. REQUEST UPLOAD URL
//       // --------------------------------------------------------

//       setStatus(
//         "Requesting asset upload URL..."
//       );

//       const uploadUrlResponse =
//         await apiRequest<UploadUrlResponse>(
//           `/api/storage/${modelResponse.id}/upload-url`,
//           {
//             method: "GET",
//           }
//         );

//       setUploadInfo(
//         uploadUrlResponse
//       );

//       // --------------------------------------------------------
//       // 3. UPLOAD GLB
//       // --------------------------------------------------------

//       setStatus(
//         "Uploading GLB asset..."
//       );


//       // const proxiedUploadUrl = getProxiedUploadUrl(uploadInfo!.uploadUrl);

//       // console.log("Original upload URL:", uploadInfo!.uploadUrl);
//       // console.log("Proxied upload URL:", proxiedUploadUrl);

//       // const uploadResponse = await fetch(proxiedUploadUrl, {
//       //   method: "PUT",
//       //   headers: {
//       //     "x-ms-blob-type": "BlockBlob",
//       //     "Content-Type": assetFile.type || "model/gltf-binary",
//       //   },
//       //   body: assetFile,
//       // });

//       const originalUploadUrl = uploadUrlResponse.uploadUrl;

//       console.log("Original SAS URL:", originalUploadUrl);

//       const sasUrl = new URL(originalUploadUrl);

//       const proxiedUploadUrl =
//         `/azurite${sasUrl.pathname}${sasUrl.search}`;

//       console.log("Proxied upload URL:", proxiedUploadUrl);

//       const uploadResponse = await fetch(proxiedUploadUrl, {
//         method: "PUT",
//         headers: {
//           "x-ms-blob-type": "BlockBlob",
//           "Content-Type": assetFile.type || "model/gltf-binary",
//         },
//         body: assetFile,
//       });

//       if (!uploadResponse.ok) {
//         const errorText = await uploadResponse.text();

//         throw new Error(
//           `Asset upload failed: ${uploadResponse.status} ${errorText}`
//         );
//       }

//       // const uploadResponse =
//       //   await fetch(
//       //     uploadUrlResponse.uploadUrl,
//       //     {
//       //       method: "PUT",

//       //       headers: {
//       //         "x-ms-blob-type":
//       //           "BlockBlob",

//       //         "Content-Type":
//       //           assetFile.type ||
//       //           "model/gltf-binary",
//       //       },

//       //       body: assetFile,
//       //     }
//       //   );

//       if (!uploadResponse.ok) {
//         const errorText =
//           await uploadResponse.text();

//         throw new Error(
//           `Asset upload failed: ${uploadResponse.status} ${errorText}`
//         );
//       }

//       setStatus(
//         `Model created and asset uploaded successfully. Blob path: ${uploadUrlResponse.blobPath}`
//       );
//     } catch (error) {
//       console.error(
//         "Create model/upload error:",
//         error
//       );

//       setStatus(
//         error instanceof Error
//           ? error.message
//           : "Unable to create model or upload asset."
//       );
//     } finally {
//       setIsCreatingModel(false);
//     }
//   }

//   // ============================================================
//   // FILE CHANGE
//   // ============================================================

//   function handleFileChange(
//     event: ChangeEvent<HTMLInputElement>
//   ) {
//     setAssetFile(
//       event.target.files?.[0] ||
//       null
//     );
//   }

//   // ============================================================
//   // UI
//   // ============================================================

//   return (
//     <main className="page">
//       <div className="container">

//         <h1>
//           AHE Model Asset Management
//         </h1>

//         {/* ====================================================
//             JWT ACCESS TOKEN
//         ==================================================== */}

//         <label>
//           JWT Access Token

//           <textarea
//             value={accessToken}
//             onChange={(event) =>
//               setAccessToken(
//                 event.target.value
//               )
//             }
//             placeholder="Paste JWT access token"
//             rows={4}
//           />
//         </label>

//         {/* ====================================================
//             SECTION 1: CREATE CATEGORY
//         ==================================================== */}

//         <section className="section">

//           <h2>
//             1. Create New Category
//           </h2>

//           <form
//             className="form"
//             onSubmit={
//               handleCreateCategory
//             }
//           >

//             <label>
//               Category Name

//               <input
//                 value={
//                   categoryName
//                 }
//                 onChange={(event) =>
//                   setCategoryName(
//                     event.target.value
//                   )
//                 }
//                 placeholder="Furniture"
//                 required
//               />
//             </label>

//             <label>
//               Category Description

//               <input
//                 value={
//                   categoryDescription
//                 }
//                 onChange={(event) =>
//                   setCategoryDescription(
//                     event.target.value
//                   )
//                 }
//                 placeholder="Furniture models"
//               />
//             </label>

//             <button
//               type="submit"
//               disabled={
//                 isCreatingCategory
//               }
//             >
//               {isCreatingCategory
//                 ? "Creating Category..."
//                 : "Create Category"}
//             </button>

//           </form>

//           {createdCategory && (
//             <div className="success-box">

//               <strong>
//                 Created Category
//               </strong>

//               <p>
//                 {
//                   createdCategory.categoryName
//                 }
//               </p>

//               <small>
//                 Category ID:{" "}
//                 {
//                   createdCategory.id ||
//                   createdCategory.categoryId
//                 }
//               </small>

//             </div>
//           )}

//         </section>

//         {/* ====================================================
//             SECTION 2: CREATE MODEL
//         ==================================================== */}

//         <section
//           className={`section ${!selectedCategoryId
//             ? "disabled-section"
//             : ""
//             }`}
//         >

//           <h2>
//             2. Create Model and Upload Asset
//           </h2>

//           {!selectedCategoryId && (
//             <p className="hint">
//               Select a category first
//               to enable this section.
//             </p>
//           )}

//           <form
//             className="form"
//             onSubmit={
//               handleCreateModelAndUpload
//             }
//           >

//             {/* CATEGORY */}

//             <label>
//               Category

//               <select
//                 value={
//                   selectedCategoryId
//                 }
//                 onChange={(event) =>
//                   setSelectedCategoryId(
//                     event.target.value
//                   )
//                 }
//                 required
//               >

//                 <option value="">
//                   Select a category
//                 </option>

//                 {categories.map(
//                   (category) => (
//                     <option
//                       key={
//                         category.id ||
//                         category.categoryId
//                       }
//                       value={
//                         category.id ||
//                         category.categoryId
//                       }
//                     >
//                       {
//                         category.categoryName
//                       }
//                     </option>
//                   )
//                 )}

//               </select>
//             </label>

//             {/* MODEL CODE */}

//             <label>
//               Model Code

//               <input
//                 value={modelCode}
//                 onChange={(event) =>
//                   setModelCode(
//                     event.target.value
//                   )
//                 }
//                 placeholder="CHAIR-001"
//                 required
//                 disabled={
//                   !selectedCategoryId
//                 }
//               />
//             </label>

//             {/* MODEL NAME */}

//             <label>
//               Model Name

//               <input
//                 value={modelName}
//                 onChange={(event) =>
//                   setModelName(
//                     event.target.value
//                   )
//                 }
//                 placeholder="Modern Chair"
//                 required
//                 disabled={
//                   !selectedCategoryId
//                 }
//               />
//             </label>

//             {/* MODEL METADATA */}

//             <label>
//               Model Metadata

//               <textarea
//                 value={
//                   modelMetadata
//                 }
//                 onChange={(event) =>
//                   setModelMetadata(
//                     event.target.value
//                   )
//                 }
//                 placeholder="Enter model metadata"
//                 rows={4}
//                 required
//                 disabled={
//                   !selectedCategoryId
//                 }
//               />
//             </label>

//             {/* REGION */}

//             <label>
//               Region

//               <select
//                 value={
//                   selectedRegionId
//                 }
//                 onChange={(event) =>
//                   setSelectedRegionId(
//                     event.target.value
//                   )
//                 }
//                 required
//                 disabled={
//                   !selectedCategoryId
//                 }
//               >

//                 <option value="">
//                   Select a region
//                 </option>

//                 {regions.map(
//                   (region) => (
//                     <option
//                       key={
//                         region.id ||
//                         region.regionId
//                       }
//                       value={
//                         region.id ||
//                         region.regionId
//                       }
//                     >
//                       {region.name}
//                     </option>
//                   )
//                 )}

//               </select>
//             </label>

//             {/* ITEM NUMBER */}

//             <label>
//               Item Number

//               <input
//                 value={itemNumber}
//                 onChange={(event) =>
//                   setItemNumber(
//                     event.target.value
//                   )
//                 }
//                 placeholder="CHAIR-001-AU"
//                 required
//                 disabled={
//                   !selectedCategoryId
//                 }
//               />
//             </label>

//             {/* PRICE */}

//             <label>
//               Price

//               <input
//                 type="number"
//                 min="0"
//                 step="0.01"
//                 value={price}
//                 onChange={(event) =>
//                   setPrice(
//                     event.target.value
//                   )
//                 }
//                 placeholder="199.99"
//                 required
//                 disabled={
//                   !selectedCategoryId
//                 }
//               />
//             </label>

//             {/* DESCRIPTION */}

//             <label>
//               Description

//               <textarea
//                 value={
//                   description
//                 }
//                 onChange={(event) =>
//                   setDescription(
//                     event.target.value
//                   )
//                 }
//                 placeholder="Enter model description"
//                 rows={4}
//                 required
//                 disabled={
//                   !selectedCategoryId
//                 }
//               />
//             </label>

//             {/* GLB FILE */}

//             <label>
//               Related GLB Asset

//               <input
//                 type="file"
//                 accept=".glb,model/gltf-binary"
//                 onChange={
//                   handleFileChange
//                 }
//                 required
//                 disabled={
//                   !selectedCategoryId
//                 }
//               />
//             </label>

//             {assetFile && (
//               <p className="file-info">
//                 Selected file:{" "}
//                 {assetFile.name}
//               </p>
//             )}

//             {/* SUBMIT */}

//             <button
//               type="submit"
//               disabled={
//                 !selectedCategoryId ||
//                 isCreatingModel
//               }
//             >
//               {isCreatingModel
//                 ? "Creating Model and Uploading..."
//                 : "Create Model and Upload Asset"}
//             </button>

//           </form>

//           {/* CREATED MODEL */}

//           {createdModel && (
//             <div className="result">

//               <h3>
//                 Created Model
//               </h3>

//               <pre>
//                 {JSON.stringify(
//                   createdModel,
//                   null,
//                   2
//                 )}
//               </pre>

//             </div>
//           )}

//           {/* UPLOAD DETAILS */}

//           {uploadInfo && (
//             <div className="result">

//               <h3>
//                 Upload Details
//               </h3>

//               <pre>
//                 {JSON.stringify(
//                   {
//                     blobPath:
//                       uploadInfo.blobPath,
//                     expiresAt:
//                       uploadInfo.expiresAt,
//                   },
//                   null,
//                   2
//                 )}
//               </pre>

//             </div>
//           )}

//         </section>

//         {/* ====================================================
//             STATUS
//         ==================================================== */}

//         {status && (
//           <div className="status">

//             <strong>
//               Status
//             </strong>

//             <p>
//               {status}
//             </p>

//           </div>
//         )}

//       </div>
//     </main>
//   );
// }

// function getProxiedUploadUrl(uploadUrl: string): string {
//   const url = new URL(uploadUrl);

//   return `/azurite${url.pathname}${url.search}`;
// }

// export default App;

// /////////////////////////////////////////////////////////////////


import {
  ChangeEvent,
  FormEvent,
  useEffect,
  useMemo,
  useState,
} from "react";
import "./App.css";

const API_BASE_URL = "http://localhost:5217";

// ============================================================
// TYPES
// ============================================================

type CategoryResponse = {
  id?: string;
  categoryId: string;
  categoryName: string;
  description?: string;
};

type RegionResponse = {
  id?: string;
  regionId: string;
  name: string;
  code?: string;
};

type TextureResponse = {
  id?: string;
  textureId: string;
  textureName: string;
  thumbnailPath?: string;
  texturePath?: string;
  isActive?: boolean;
};

type ModelResponse = {
  id: string;
  modelId: string;
  modelName: string;
  categoryId: string;
  modelPath?: string;
  variants?: ModelVariantResponse[];
};

type ModelVariantResponse = {
  modelId: string;
  textureId: string;
  skuNumber: string;
  thumbnailPath?: string;
  regions?: ModelVariantRegionResponse[];
};

type ModelVariantRegionResponse = {
  regionId: string;
  itemNumber: string;
  price: number;
};

type UploadUrlResponse = {
  modelId: string;
  blobPath: string;
  uploadUrl: string;
  expiresAt: string;
};

type VariantRegion = {
  regionId: string;
  itemNumber: string;
};

type ModelVariantForm = {
  id: string;
  textureId: string;
  skuNumber: string;
  thumbnailFile: File | null;
  regions: VariantRegion[];
};

// ============================================================
// HELPERS
// ============================================================

function getEntityId(entity: {
  id?: string;
  categoryId?: string;
  regionId?: string;
  textureId?: string;
}): string {
  return (
    entity.id ||
    entity.categoryId ||
    entity.regionId ||
    entity.textureId ||
    ""
  );
}

function getProxiedUploadUrl(uploadUrl: string): string {
  const url = new URL(uploadUrl);

  return `/azurite${url.pathname}${url.search}`;
}

function createEmptyVariant(): ModelVariantForm {
  return {
    id: crypto.randomUUID(),
    textureId: "",
    skuNumber: "",
    thumbnailFile: null,
    regions: [],
  };
}

// ============================================================
// APP
// ============================================================

function App() {
  const [accessToken, setAccessToken] = useState("");

  // ============================================================
  // CATEGORY STATE
  // ============================================================

  const [categoryName, setCategoryName] = useState("");
  const [categoryDescription, setCategoryDescription] =
    useState("");

  const [createdCategory, setCreatedCategory] =
    useState<CategoryResponse | null>(null);

  const [categories, setCategories] = useState<
    CategoryResponse[]
  >([]);

  const [selectedCategoryId, setSelectedCategoryId] =
    useState("");

  // ============================================================
  // REGION STATE
  // ============================================================

  const [regions, setRegions] = useState<
    RegionResponse[]
  >([]);

  // ============================================================
  // TEXTURE STATE
  // ============================================================

  const [textures, setTextures] = useState<
    TextureResponse[]
  >([]);

  // ============================================================
  // MODEL STATE
  // ============================================================

  const [modelCode, setModelCode] = useState("");
  const [modelName, setModelName] = useState("");
  const [description, setDescription] = useState("");

  const [assetFile, setAssetFile] =
    useState<File | null>(null);

  const [variants, setVariants] = useState<
    ModelVariantForm[]
  >([createEmptyVariant()]);

  // ============================================================
  // RESULT STATE
  // ============================================================

  const [createdModel, setCreatedModel] =
    useState<ModelResponse | null>(null);

  const [uploadInfo, setUploadInfo] =
    useState<UploadUrlResponse | null>(null);

  const [status, setStatus] = useState("");

  const [isCreatingCategory, setIsCreatingCategory] =
    useState(false);

  const [isCreatingModel, setIsCreatingModel] =
    useState(false);

  // ============================================================
  // GENERIC API REQUEST
  // ============================================================

  async function apiRequest<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${API_BASE_URL}${endpoint}`;

    console.log(
      "API Request:",
      options.method || "GET",
      url
    );

    const response = await fetch(url, {
      ...options,
      headers: {
        ...(accessToken
          ? {
              Authorization: `Bearer ${accessToken}`,
            }
          : {}),
        ...(options.headers || {}),
      },
    });

    console.log(
      "API Response:",
      response.status,
      response.statusText,
      url
    );

    if (!response.ok) {
      const errorText = await response.text();

      console.error("API Error:", {
        url,
        status: response.status,
        statusText: response.statusText,
        response: errorText,
      });

      throw new Error(
        `${response.status} ${response.statusText}: ${errorText}`
      );
    }

    return response.json();
  }

  // ============================================================
  // LOAD CATEGORIES
  // ============================================================

  async function loadCategories() {
    try {
      const response =
        await apiRequest<CategoryResponse[]>(
          "/api/Categories",
          {
            method: "GET",
          }
        );

      setCategories(response);
    } catch (error) {
      console.error(
        "Unable to load categories:",
        error
      );

      setStatus(
        error instanceof Error
          ? error.message
          : "Unable to load categories."
      );
    }
  }

  // ============================================================
  // LOAD REGIONS
  // ============================================================

  async function loadRegions() {
    try {
      const response =
        await apiRequest<RegionResponse[]>(
          "/api/Regions",
          {
            method: "GET",
          }
        );

      setRegions(response);
    } catch (error) {
      console.error(
        "Unable to load regions:",
        error
      );

      setStatus(
        error instanceof Error
          ? error.message
          : "Unable to load regions."
      );
    }
  }

  // ============================================================
  // LOAD TEXTURES
  // ============================================================

  async function loadTextures() {
    try {
      const response =
        await apiRequest<TextureResponse[]>(
          "/api/Textures",
          {
            method: "GET",
          }
        );

      setTextures(
        response.filter(
          (texture) => texture.isActive !== false
        )
      );
    } catch (error) {
      console.error(
        "Unable to load textures:",
        error
      );

      setStatus(
        error instanceof Error
          ? error.message
          : "Unable to load textures."
      );
    }
  }

  // ============================================================
  // LOAD DROPDOWN DATA WHEN JWT IS AVAILABLE
  // ============================================================

  useEffect(() => {
    if (!accessToken.trim()) {
      setCategories([]);
      setRegions([]);
      setTextures([]);
      setSelectedCategoryId("");
      return;
    }

    loadCategories();
    loadRegions();
    loadTextures();
  }, [accessToken]);

  // ============================================================
  // CREATE CATEGORY
  // ============================================================

  async function handleCreateCategory(
    event: FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();

    if (!accessToken.trim()) {
      setStatus(
        "Please enter your JWT access token."
      );
      return;
    }

    if (!categoryName.trim()) {
      setStatus("Please enter a category name.");
      return;
    }

    setIsCreatingCategory(true);
    setStatus("");

    try {
      const response =
        await apiRequest<CategoryResponse>(
          "/api/Categories",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              categoryId: crypto.randomUUID(),
              categoryName: categoryName.trim(),
              description: categoryDescription.trim(),
            }),
          }
        );

      setCreatedCategory(response);

      await loadCategories();

      setStatus(
        "Category created successfully."
      );

      setCategoryName("");
      setCategoryDescription("");
    } catch (error) {
      console.error(
        "Create category error:",
        error
      );

      setStatus(
        error instanceof Error
          ? error.message
          : "Unable to create category."
      );
    } finally {
      setIsCreatingCategory(false);
    }
  }

  // ============================================================
  // VARIANT HELPERS
  // ============================================================

  function updateVariant(
    variantId: string,
    updates: Partial<ModelVariantForm>
  ) {
    setVariants((previous) =>
      previous.map((variant) =>
        variant.id === variantId
          ? { ...variant, ...updates }
          : variant
      )
    );
  }

  function updateVariantRegion(
    variantId: string,
    regionId: string,
    updates: Partial<VariantRegion>
  ) {
    setVariants((previous) =>
      previous.map((variant) => {
        if (variant.id !== variantId) {
          return variant;
        }

        return {
          ...variant,
          regions: variant.regions.map((region) =>
            region.regionId === regionId
              ? { ...region, ...updates }
              : region
          ),
        };
      })
    );
  }

  function toggleVariantRegion(
    variantId: string,
    regionId: string,
    checked: boolean
  ) {
    setVariants((previous) =>
      previous.map((variant) => {
        if (variant.id !== variantId) {
          return variant;
        }

        if (checked) {
          if (
            variant.regions.some(
              (region) => region.regionId === regionId
            )
          ) {
            return variant;
          }

          return {
            ...variant,
            regions: [
              ...variant.regions,
              {
                regionId,
                itemNumber: "",
              },
            ],
          };
        }

        return {
          ...variant,
          regions: variant.regions.filter(
            (region) => region.regionId !== regionId
          ),
        };
      })
    );
  }

  function addVariant() {
    if (variants.length >= textures.length) {
      setStatus(
        "You cannot add more variants than the available textures."
      );
      return;
    }

    setVariants((previous) => [
      ...previous,
      createEmptyVariant(),
    ]);

    setStatus("");
  }

  function removeVariant(variantId: string) {
    if (variants.length === 1) {
      setStatus(
        "At least one variant is required."
      );
      return;
    }

    setVariants((previous) =>
      previous.filter(
        (variant) => variant.id !== variantId
      )
    );
  }

  // ============================================================
  // TEXTURE SELECTION
  // ============================================================

  const selectedTextureIds = useMemo(
    () =>
      new Set(
        variants
          .map((variant) => variant.textureId)
          .filter(Boolean)
      ),
    [variants]
  );

  function getAvailableTextures(
    currentVariantId: string
  ) {
    const currentVariant = variants.find(
      (variant) => variant.id === currentVariantId
    );

    return textures.filter(
      (texture) =>
        texture.textureId === currentVariant?.textureId ||
        !selectedTextureIds.has(texture.textureId)
    );
  }

  // ============================================================
  // FILE CHANGE HANDLERS
  // ============================================================

  function handleAssetFileChange(
    event: ChangeEvent<HTMLInputElement>
  ) {
    const file = event.target.files?.[0] || null;

    if (file && !file.name.toLowerCase().endsWith(".glb")) {
      setStatus("Please select a GLB file.");
      setAssetFile(null);
      return;
    }

    setAssetFile(file);
  }

  function handleThumbnailChange(
    variantId: string,
    event: ChangeEvent<HTMLInputElement>
  ) {
    const file = event.target.files?.[0] || null;

    if (file && !file.type.startsWith("image/")) {
      setStatus(
        "Please select a valid thumbnail image."
      );
      return;
    }

    updateVariant(variantId, {
      thumbnailFile: file,
    });
  }

  // ============================================================
  // VALIDATE FORM
  // ============================================================

  function validateModelForm(): string | null {
    if (!accessToken.trim()) {
      return "Please enter your JWT access token.";
    }

    if (!selectedCategoryId) {
      return "Please select a category.";
    }

    if (!modelCode.trim()) {
      return "Please enter a model code.";
    }

    if (!modelName.trim()) {
      return "Please enter a model name.";
    }

    if (!description.trim()) {
      return "Please enter a model description.";
    }

    if (!assetFile) {
      return "Please select a GLB asset.";
    }

    if (variants.length === 0) {
      return "At least one variant is required.";
    }

    if (variants.length > textures.length) {
      return "The number of variants cannot exceed the number of textures.";
    }

    const textureIds = new Set<string>();

    for (let i = 0; i < variants.length; i++) {
      const variant = variants[i];

      if (!variant.textureId) {
        return `Please select a texture for Variant ${i + 1}.`;
      }

      if (textureIds.has(variant.textureId)) {
        return `Texture cannot be repeated in Variant ${i + 1}.`;
      }

      textureIds.add(variant.textureId);

      if (!variant.skuNumber.trim()) {
        return `Please enter a SKU for Variant ${i + 1}.`;
      }

      if (!variant.thumbnailFile) {
        return `Please select a thumbnail for Variant ${i + 1}.`;
      }

      if (variant.regions.length === 0) {
        return `Please select at least one region for Variant ${i + 1}.`;
      }

      for (const region of variant.regions) {
        if (!region.itemNumber.trim()) {
          const regionName =
            regions.find(
              (item) =>
                getEntityId(item) === region.regionId
            )?.name || region.regionId;

          return `Please enter an item number for ${regionName} in Variant ${i + 1}.`;
        }
      }
    }

    return null;
  }

  // ============================================================
  // CREATE MODEL AND UPLOAD ASSET
  // ============================================================

  async function handleCreateModelAndUpload(
    event: FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();

    const validationError = validateModelForm();

    if (validationError) {
      setStatus(validationError);
      return;
    }

    if (!assetFile) {
      return;
    }

    setIsCreatingModel(true);
    setStatus("");
    setCreatedModel(null);
    setUploadInfo(null);

    try {
      // --------------------------------------------------------
      // 1. CREATE MODEL WITH VARIANTS
      // --------------------------------------------------------

      setStatus("Creating model and variants...");

      const modelResponse =
        await apiRequest<ModelResponse>(
          "/api/Models",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              modelId: modelCode.trim(),

              categoryId: selectedCategoryId,

              modelName: modelName.trim(),

              // Retain this if your current backend
              // still requires ModelPath.
              // Remove it when the DTO is updated
              // to make ModelPath nullable.
              modelPath: "pending",

              description: description.trim(),

              isActive: true,

              variants: variants.map((variant) => ({
                textureId: variant.textureId,

                skuNumber: variant.skuNumber.trim(),

                // The backend can replace this
                // with a generated storage path.
                thumbnailPath:
                  variant.thumbnailFile?.name || null,

                regions: variant.regions.map((region) => ({
                  regionId: region.regionId,

                  itemNumber: region.itemNumber.trim(),

                  // Include price if required by
                  // your existing ModelRegion DTO.
                  price: 0,
                })),
              })),
            }),
          }
        );

      setCreatedModel(modelResponse);

      // --------------------------------------------------------
      // 2. REQUEST MODEL UPLOAD URL
      // --------------------------------------------------------

      setStatus("Requesting GLB upload URL...");

      const uploadUrlResponse =
        await apiRequest<UploadUrlResponse>(
          `/api/storage/${modelResponse.id}/upload-url`,
          {
            method: "GET",
          }
        );

      setUploadInfo(uploadUrlResponse);

      // --------------------------------------------------------
      // 3. UPLOAD GLB ASSET TO AZURITE
      // --------------------------------------------------------

      setStatus("Uploading GLB asset...");

      const proxiedUploadUrl = getProxiedUploadUrl(
        uploadUrlResponse.uploadUrl
      );

      console.log(
        "Original SAS URL:",
        uploadUrlResponse.uploadUrl
      );

      console.log(
        "Proxied upload URL:",
        proxiedUploadUrl
      );

      const uploadResponse = await fetch(
        proxiedUploadUrl,
        {
          method: "PUT",
          headers: {
            "x-ms-blob-type": "BlockBlob",
            "Content-Type":
              assetFile.type || "model/gltf-binary",
          },
          body: assetFile,
        }
      );

      if (!uploadResponse.ok) {
        const errorText = await uploadResponse.text();

        throw new Error(
          `Asset upload failed: ${uploadResponse.status} ${errorText}`
        );
      }

      setStatus(
        `Model created successfully with ${variants.length} variant(s), and GLB asset uploaded.`
      );
    } catch (error) {
      console.error(
        "Create model/upload error:",
        error
      );

      setStatus(
        error instanceof Error
          ? error.message
          : "Unable to create model or upload asset."
      );
    } finally {
      setIsCreatingModel(false);
    }
  }

  // ============================================================
  // UI
  // ============================================================

  return (
    <main className="page">
      <div className="container">
        <h1>
          AHE Model Asset Management
        </h1>

        {/* ====================================================
            JWT ACCESS TOKEN
        ==================================================== */}

        <section className="section">
          <h2>JWT Access Token</h2>

          <label>
            Access Token

            <textarea
              value={accessToken}
              onChange={(event) =>
                setAccessToken(event.target.value)
              }
              placeholder="Paste JWT access token"
              rows={4}
            />
          </label>
        </section>

        {/* ====================================================
            CREATE CATEGORY
        ==================================================== */}

        <section className="section">
          <h2>1. Create New Category</h2>

          <form
            className="form"
            onSubmit={handleCreateCategory}
          >
            <label>
              Category Name

              <input
                value={categoryName}
                onChange={(event) =>
                  setCategoryName(event.target.value)
                }
                placeholder="Furniture"
                required
              />
            </label>

            <label>
              Category Description

              <input
                value={categoryDescription}
                onChange={(event) =>
                  setCategoryDescription(
                    event.target.value
                  )
                }
                placeholder="Furniture models"
              />
            </label>

            <button
              type="submit"
              disabled={isCreatingCategory}
            >
              {isCreatingCategory
                ? "Creating Category..."
                : "Create Category"}
            </button>
          </form>

          {createdCategory && (
            <div className="success-box">
              <strong>Created Category</strong>

              <p>
                {createdCategory.categoryName}
              </p>

              <small>
                Category ID:{" "}
                {getEntityId(createdCategory)}
              </small>
            </div>
          )}
        </section>

        {/* ====================================================
            CREATE MODEL
        ==================================================== */}

        <section
          className={`section ${
            !selectedCategoryId
              ? "disabled-section"
              : ""
          }`}
        >
          <h2>2. Create Model</h2>

          {!selectedCategoryId && (
            <p className="hint">
              Select a category first to enable
              this section.
            </p>
          )}

          <form
            className="form"
            onSubmit={handleCreateModelAndUpload}
          >
            {/* CATEGORY */}

            <label>
              Category

              <select
                value={selectedCategoryId}
                onChange={(event) =>
                  setSelectedCategoryId(
                    event.target.value
                  )
                }
                required
              >
                <option value="">
                  Select a category
                </option>

                {categories.map((category) => (
                  <option
                    key={getEntityId(category)}
                    value={getEntityId(category)}
                  >
                    {category.categoryName}
                  </option>
                ))}
              </select>
            </label>

            {/* MODEL CODE */}

            <label>
              Model Code

              <input
                value={modelCode}
                onChange={(event) =>
                  setModelCode(event.target.value)
                }
                placeholder="UT-300"
                required
                disabled={!selectedCategoryId}
              />
            </label>

            {/* MODEL NAME */}

            <label>
              Model Name

              <input
                value={modelName}
                onChange={(event) =>
                  setModelName(event.target.value)
                }
                placeholder="UT 300 base"
                required
                disabled={!selectedCategoryId}
              />
            </label>

            {/* DESCRIPTION */}

            <label>
              Description

              <textarea
                value={description}
                onChange={(event) =>
                  setDescription(event.target.value)
                }
                placeholder="300mm Floor Cupboard"
                rows={3}
                required
                disabled={!selectedCategoryId}
              />
            </label>

            {/* GLB ASSET */}

            <label>
              3D Model

              <input
                type="file"
                accept=".glb,model/gltf-binary"
                onChange={handleAssetFileChange}
                required
                disabled={!selectedCategoryId}
              />
            </label>

            {assetFile && (
              <p className="file-info">
                Selected file: {assetFile.name}
              </p>
            )}

            {/* ====================================================
                VARIANTS
            ==================================================== */}

            <div className="variants-section">
              <div className="variants-header">
                <h3>Variants</h3>

                <span className="hint">
                  {variants.length} / {textures.length}{" "}
                  variants
                </span>
              </div>

              <p className="hint">
                Each texture can be selected only
                once. Add variants for different
                textures of this model.
              </p>

              {textures.length === 0 && (
                <div className="hint">
                  No textures available. Please
                  create or load textures first.
                </div>
              )}

              {variants.map((variant, index) => (
                <div
                  className="variant-card"
                  key={variant.id}
                >
                  <div className="variant-header">
                    <h3>
                      Variant {index + 1}
                    </h3>

                    {variants.length > 1 && (
                      <button
                        type="button"
                        className="remove-button"
                        onClick={() =>
                          removeVariant(variant.id)
                        }
                        disabled={isCreatingModel}
                      >
                        Remove
                      </button>
                    )}
                  </div>

                  {/* TEXTURE */}

                  <label>
                    Range / Texture

                    <select
                      value={variant.textureId}
                      onChange={(event) =>
                        updateVariant(
                          variant.id,
                          {
                            textureId:
                              event.target.value,
                          }
                        )
                      }
                      required
                      disabled={
                        !selectedCategoryId ||
                        isCreatingModel
                      }
                    >
                      <option value="">
                        Select a texture
                      </option>

                      {getAvailableTextures(
                        variant.id
                      ).map((texture) => (
                        <option
                          key={texture.textureId}
                          value={texture.textureId}
                        >
                          {texture.textureName}
                        </option>
                      ))}
                    </select>
                  </label>

                  {/* SKU */}

                  <label>
                    SKU Number

                    <input
                      value={variant.skuNumber}
                      onChange={(event) =>
                        updateVariant(
                          variant.id,
                          {
                            skuNumber:
                              event.target.value,
                          }
                        )
                      }
                      placeholder="W-56017"
                      required
                      disabled={isCreatingModel}
                    />
                  </label>

                  {/* THUMBNAIL */}

                  <label>
                    Thumbnail

                    <input
                      type="file"
                      accept="image/*"
                      onChange={(event) =>
                        handleThumbnailChange(
                          variant.id,
                          event
                        )
                      }
                      required
                      disabled={isCreatingModel}
                    />
                  </label>

                  {variant.thumbnailFile && (
                    <p className="file-info">
                      Selected thumbnail:{" "}
                      {variant.thumbnailFile.name}
                    </p>
                  )}

                  {/* REGIONS */}

                  <div className="variant-regions">
                    <h4>Available Regions</h4>

                    {regions.map((region) => {
                      const regionId =
                        getEntityId(region);

                      const selectedRegion =
                        variant.regions.find(
                          (item) =>
                            item.regionId === regionId
                        );

                      const isSelected =
                        Boolean(selectedRegion);

                      return (
                        <div
                          className="region-row"
                          key={regionId}
                        >
                          <label className="region-checkbox">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={(event) =>
                                toggleVariantRegion(
                                  variant.id,
                                  regionId,
                                  event.target.checked
                                )
                              }
                              disabled={
                                isCreatingModel
                              }
                            />

                            <span>
                              {region.code ||
                                region.name}
                            </span>
                          </label>

                          {isSelected && (
                            <label>
                              Item Number

                              <input
                                value={
                                  selectedRegion
                                    ?.itemNumber || ""
                                }
                                onChange={(event) =>
                                  updateVariantRegion(
                                    variant.id,
                                    regionId,
                                    {
                                      itemNumber:
                                        event.target
                                          .value,
                                    }
                                  )
                                }
                                placeholder="10001"
                                required
                                disabled={
                                  isCreatingModel
                                }
                              />
                            </label>
                          )}
                        </div>
                      );
                    })}

                    {regions.length === 0 && (
                      <p className="hint">
                        No regions available.
                      </p>
                    )}
                  </div>
                </div>
              ))}

              {/* ADD VARIANT */}

              <button
                type="button"
                className="add-variant-button"
                onClick={addVariant}
                disabled={
                  isCreatingModel ||
                  textures.length === 0 ||
                  variants.length >= textures.length
                }
              >
                + Add Variant
              </button>

              {variants.length >= textures.length &&
                textures.length > 0 && (
                  <p className="hint">
                    All available textures have
                    been assigned. No more variants
                    can be added.
                  </p>
                )}
            </div>

            {/* SUBMIT */}

            <button
              type="submit"
              disabled={
                !selectedCategoryId ||
                isCreatingModel ||
                textures.length === 0
              }
            >
              {isCreatingModel
                ? "Creating Model and Uploading..."
                : "Create Model"}
            </button>
          </form>

          {/* ====================================================
              CREATED MODEL
          ==================================================== */}

          {createdModel && (
            <div className="result">
              <h3>Created Model</h3>

              <pre>
                {JSON.stringify(
                  createdModel,
                  null,
                  2
                )}
              </pre>
            </div>
          )}

          {/* ====================================================
              UPLOAD DETAILS
          ==================================================== */}

          {uploadInfo && (
            <div className="result">
              <h3>Upload Details</h3>

              <pre>
                {JSON.stringify(
                  {
                    blobPath:
                      uploadInfo.blobPath,
                    expiresAt:
                      uploadInfo.expiresAt,
                  },
                  null,
                  2
                )}
              </pre>
            </div>
          )}
        </section>

        {/* ====================================================
            STATUS
        ==================================================== */}

        {status && (
          <div className="status">
            <strong>Status</strong>

            <p>{status}</p>
          </div>
        )}
      </div>
    </main>
  );
}

export default App;