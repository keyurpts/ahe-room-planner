import { create } from 'zustand';

type ColorScheme = 'system' | 'light' | 'dark';

interface UiState {
  colorScheme: ColorScheme;
  setColorScheme: (colorScheme: ColorScheme) => void;
}

// Preference state only; theme rendering will follow the supplied designs.
export const useUiStore = create<UiState>()((set) => ({
  colorScheme: 'system',
  setColorScheme: (colorScheme) => {
    set({ colorScheme });
  },
}));
