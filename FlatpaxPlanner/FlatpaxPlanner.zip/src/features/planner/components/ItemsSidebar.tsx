import { useId, useState } from 'react';
import { cabinetCategories, type CatalogueProduct } from '@/features/planner/catalogue/catalogue';

interface Props {
  onAdd: (product: CatalogueProduct) => void;
  onSelect: (id: string) => void;
  selected: string | null;
  canCustomise: boolean;
  onCustomise: () => void;
  hidden?: boolean;
}

function Chevron({ expanded }: { expanded?: boolean | undefined }) {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
      <path
        d={expanded === undefined ? 'm6 4 5 5-5 5' : expanded ? 'm4 11 5-5 5 5' : 'm4 6 5 5 5-5'}
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function ItemsSidebar({
  onAdd,
  onSelect,
  selected,
  canCustomise,
  onCustomise,
  hidden = false,
}: Props) {
  const [openSections, setOpenSections] = useState<readonly string[]>([
    'cupboard',
    'benchtop',
    'cabinets',
  ]);
  const [category, setCategory] = useState<string | null>('floor');
  const id = useId();
  function toggle(section: string) {
    setOpenSections((current) =>
      current.includes(section)
        ? current.filter((value) => value !== section)
        : [...current, section],
    );
  }

  return (
    <aside className="items-sidebar" aria-label="Product catalogue" hidden={hidden}>
      <div className="items-sidebar-content">
        {(
          [
            { id: 'cupboard', title: 'Cupboard colour', value: 'White' },
            { id: 'benchtop', title: 'Benchtop colour', value: 'Grey' },
          ] as const
        ).map((section) => (
          <section className="catalogue-section" key={section.id}>
            <h2>
              <button
                type="button"
                className="catalogue-section-toggle"
                aria-expanded={openSections.includes(section.id)}
                aria-controls={`${id}-${section.id}`}
                onClick={() => {
                  toggle(section.id);
                }}
              >
                {section.title}
                <Chevron expanded={openSections.includes(section.id)} />
              </button>
            </h2>
            <div
              id={`${id}-${section.id}`}
              hidden={!openSections.includes(section.id)}
              className="catalogue-colour-value"
            >
              {section.value}
            </div>
          </section>
        ))}
        <section className="catalogue-section">
          <h2>
            <button
              type="button"
              className="catalogue-section-toggle"
              aria-expanded={openSections.includes('cabinets')}
              aria-controls={`${id}-cabinets`}
              onClick={() => {
                toggle('cabinets');
              }}
            >
              Cabinets
              <Chevron expanded={openSections.includes('cabinets')} />
            </button>
          </h2>
          <div
            id={`${id}-cabinets`}
            hidden={!openSections.includes('cabinets')}
            className="cabinet-categories"
          >
            {cabinetCategories.map((group) => (
              <section key={group.id}>
                <h3>
                  <button
                    type="button"
                    className="catalogue-category-toggle"
                    aria-expanded={category === group.id}
                    aria-controls={`${id}-${group.id}`}
                    onClick={() => {
                      setCategory(category === group.id ? null : group.id);
                    }}
                  >
                    {group.label}
                    <Chevron expanded={category === group.id ? true : undefined} />
                  </button>
                </h3>
                <div id={`${id}-${group.id}`} hidden={category !== group.id}>
                  {group.products.length ? (
                    group.products.map((product, index) => (
                      <div
                        className="catalogue-product"
                        data-selected={selected === product.id}
                        key={product.id}
                      >
                        <button
                          type="button"
                          className="catalogue-product-preview"
                          aria-label={`Select ${product.name}, variant ${String(index + 1)}`}
                          aria-pressed={selected === product.id}
                          onClick={() => {
                            onSelect(product.id);
                          }}
                        >
                          <img src={product.image} width={48} height={50} alt="" />
                          <span>
                            {product.dimensionLabel ? (
                              <>
                                <span className="catalogue-product-size">
                                  {product.dimensionLabel}
                                </span>
                                {product.name.replace(`${product.dimensionLabel} `, '')}
                              </>
                            ) : (
                              product.name
                            )}
                          </span>
                        </button>
                        <button
                          type="button"
                          className="catalogue-add"
                          aria-label={`Add ${product.name}, variant ${String(index + 1)}`}
                          onClick={() => {
                            onSelect(product.id);
                            onAdd(product);
                          }}
                        >
                          <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
                            <circle cx="9" cy="9" r="8" fill="currentColor" />
                            <path d="M9 5v8M5 9h8" stroke="white" strokeWidth="1.5" />
                          </svg>
                        </button>
                      </div>
                    ))
                  ) : (
                    <p className="catalogue-empty">No items available.</p>
                  )}
                </div>
              </section>
            ))}
          </div>
        </section>
        <section className="catalogue-section">
          <h2>
            <button
              type="button"
              className="catalogue-section-toggle"
              aria-expanded={openSections.includes('appliances')}
              aria-controls={`${id}-appliances`}
              onClick={() => {
                toggle('appliances');
              }}
            >
              Appliances
              <Chevron expanded={openSections.includes('appliances')} />
            </button>
          </h2>
          <div id={`${id}-appliances`} hidden={!openSections.includes('appliances')}>
            <p className="catalogue-empty">No items available.</p>
          </div>
        </section>
      </div>
      {canCustomise && (
        <button
          type="button"
          id="catalogue-customise"
          className="catalogue-customise"
          onClick={onCustomise}
        >
          Customise
          <svg width="28" height="20" viewBox="0 0 28 20" fill="none" aria-hidden="true">
            <path
              d="M2 10h24m0 0-7-7m7 7-7 7"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
      )}
    </aside>
  );
}
