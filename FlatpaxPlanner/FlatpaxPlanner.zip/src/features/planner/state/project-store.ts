import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type { PlannerDraft } from '@/features/planner/types';

interface ProjectState {
  draft: PlannerDraft | null;
  startProject: (draft: PlannerDraft) => void;
  discardProject: () => void;
}

function isDraft(value: unknown): value is PlannerDraft {
  if (!value || typeof value !== 'object') return false;
  return (
    'projectName' in value &&
    typeof value.projectName === 'string' &&
    Boolean(value.projectName.trim()) &&
    'roomType' in value &&
    typeof value.roomType === 'string' &&
    ['Kitchen', 'Laundry', 'Office', 'Linen', 'Garage', 'Other'].includes(value.roomType) &&
    'shape' in value &&
    typeof value.shape === 'string' &&
    [
      'rectangle',
      'l-top-left',
      'l-top-right',
      'square',
      'l-bottom-right',
      'l-bottom-left',
    ].includes(value.shape)
  );
}

export const useProjectStore = create<ProjectState>()(
  persist(
    (set) => ({
      draft: null,
      discardProject: () => {
        set({ draft: null });
      },
      startProject: (draft) => {
        set({ draft });
      },
    }),
    {
      name: 'flatpax-planner-draft',
      version: 1,
      storage: createJSONStorage(() => sessionStorage),
      partialize: (state) => ({ draft: state.draft }),
      merge: (persisted: unknown, current) => ({
        ...current,
        draft:
          persisted &&
          typeof persisted === 'object' &&
          'draft' in persisted &&
          isDraft(persisted.draft)
            ? persisted.draft
            : null,
      }),
    },
  ),
);
