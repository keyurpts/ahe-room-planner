import cupboardImage from '@/assets/images/cupboard-placeholder.svg';

export interface CatalogueProduct {
  id: string;
  name: string;
  image: string;
  dimensionLabel?: string;
}
export interface CatalogueCategory {
  id: string;
  label: string;
  products: readonly CatalogueProduct[];
}

// Temporary presentation data; a future catalogue service can supply the same contract.
export const cabinetCategories: readonly CatalogueCategory[] = [
  {
    id: 'floor',
    label: 'Floor Cupboards',
    products: Array.from({ length: 4 }, (_, index) => ({
      id: `floor-${String(index + 1)}`,
      name: '600mm Floor Cupboards',
      dimensionLabel: '600mm',
      image: cupboardImage,
    })),
  },
  ...[
    'Corner Base Cupboard',
    'Sink Cupboards',
    'Appliance Cupboards',
    'Tall Cupboards',
    'Wall Cupboards',
    'Feature Cupboards',
  ].map((label) => ({ id: label.toLowerCase().replaceAll(' ', '-'), label, products: [] })),
];
