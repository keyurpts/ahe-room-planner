﻿using AHE.BLL.DTOs.Models;
using AHE.BLL.Interfaces;
using AHE.DAL.Entities;
using AHE.DAL.Interfaces.Repositories;
using AHE.DAL.Repositories;

namespace AHE.BLL.Services;

public class ModelService : IModelService
{
    private readonly IModelRepository _modelRepository;
    private readonly ICategoryRepository _categoryRepository;
    private readonly IRegionRepository _regionRepository;
    private readonly IUserRepository _userRepository;
    private readonly ITextureRepository _textureRepository;



    public ModelService(
        IModelRepository modelRepository,
        ICategoryRepository categoryRepository,
        IRegionRepository regionRepository,
        IUserRepository userRepository,
        ITextureRepository textureRepository)
    {
        _modelRepository = modelRepository;
        _categoryRepository = categoryRepository;
        _regionRepository = regionRepository;
        _userRepository = userRepository;
        _textureRepository = textureRepository;
    }

    public async Task<List<ModelResponse>> GetAllAsync()
    {
        var models =
            await _modelRepository.GetAllAsync();

        return models
            .Select(MapToResponse)
            .ToList();
    }

    public async Task<List<ModelResponse>> GetByCategoryIdAsync(
        Guid categoryId)
    {
        var models =
            await _modelRepository
                .GetByCategoryIdAsync(categoryId);

        return models
            .Select(MapToResponse)
            .ToList();
    }

    public async Task<ModelResponse?> GetByIdAsync(Guid id)
    {
        var model =
            await _modelRepository.GetByIdAsync(id);

        return model == null
            ? null
            : MapToResponse(model);
    }

    //public async Task<ModelResponse> CreateAsync(
    //    CreateModelRequest request)
    //{
    //    if (string.IsNullOrWhiteSpace(request.ModelId))
    //    {
    //        throw new ArgumentException(
    //            "Model ID is required.");
    //    }

    //    if (string.IsNullOrWhiteSpace(request.ModelName))
    //    {
    //        throw new ArgumentException(
    //            "Model name is required.");
    //    }

    //    if (string.IsNullOrWhiteSpace(request.ModelPath))
    //    {
    //        throw new ArgumentException(
    //            "Model path is required.");
    //    }

    //    // Verify Category
    //    var category =
    //        await _categoryRepository
    //            .GetByIdAsync(request.CategoryId);

    //    if (category == null)
    //    {
    //        throw new InvalidOperationException(
    //            "Category not found.");
    //    }

    //    if (!category.IsActive)
    //    {
    //        throw new InvalidOperationException(
    //            "Category is inactive.");
    //    }

    //    // Check ModelId uniqueness
    //    var existingModel =
    //        await _modelRepository
    //            .GetByModelIdAsync(request.ModelId.Trim());

    //    if (existingModel != null)
    //    {
    //        throw new InvalidOperationException(
    //            "Model ID already exists.");
    //    }

    //    var now = DateTime.UtcNow;

    //    var model = new Model
    //    {
    //        Id = Guid.NewGuid(),

    //        ModelId = request.ModelId.Trim(),

    //        CategoryId = request.CategoryId,

    //        ModelName = request.ModelName.Trim(),

    //        ModelPath = request.ModelPath.Trim(),

    //        ModelThumbnailPath =
    //            request.ModelThumbnailPath?.Trim(),

    //        ModelMetadata = request.ModelMetadata,

    //        IsActive = true,

    //        CreatedAt = now,

    //        UpdatedAt = now,

    //        DeletedAt = null
    //    };

    //    await _modelRepository.AddAsync(model);

    //    return MapToResponse(model);
    //}

    //public async Task<ModelResponse> CreateAsync(
    //CreateModelRequest request)
    //{
    //    if (string.IsNullOrWhiteSpace(request.ModelId))
    //    {
    //        throw new ArgumentException(
    //            "Model ID is required.");
    //    }

    //    if (string.IsNullOrWhiteSpace(request.ModelName))
    //    {
    //        throw new ArgumentException(
    //            "Model name is required.");
    //    }

    //    if (string.IsNullOrWhiteSpace(request.ModelPath))
    //    {
    //        throw new ArgumentException(
    //            "Model path is required.");
    //    }

    //    if (request.Regions == null ||
    //        request.Regions.Count == 0)
    //    {
    //        throw new ArgumentException(
    //            "At least one region is required.");
    //    }

    //    // Verify Category
    //    var category =
    //        await _categoryRepository
    //            .GetByIdAsync(request.CategoryId);

    //    if (category == null)
    //    {
    //        throw new InvalidOperationException(
    //            "Category not found.");
    //    }

    //    if (!category.IsActive)
    //    {
    //        throw new InvalidOperationException(
    //            "Category is inactive.");
    //    }

    //    // Check duplicate regions
    //    var duplicateRegion =
    //        request.Regions
    //            .GroupBy(x => x.RegionId)
    //            .Any(g => g.Count() > 1);

    //    if (duplicateRegion)
    //    {
    //        throw new ArgumentException(
    //            "Duplicate regions are not allowed.");
    //    }

    //    // Verify regions
    //    foreach (var regionRequest in request.Regions)
    //    {
    //        var region =
    //            await _regionRepository
    //                .GetByIdAsync(regionRequest.RegionId);

    //        if (region == null)
    //        {
    //            throw new InvalidOperationException(
    //                $"Region {regionRequest.RegionId} not found.");
    //        }

    //        if (!region.IsActive)
    //        {
    //            throw new InvalidOperationException(
    //                $"Region {regionRequest.RegionId} is inactive.");
    //        }

    //        if (regionRequest.Price < 0)
    //        {
    //            throw new ArgumentException(
    //                "Price cannot be negative.");
    //        }
    //    }

    //    var now = DateTime.UtcNow;

    //    var model = new Model
    //    {
    //        Id = Guid.NewGuid(),

    //        CategoryId = request.CategoryId,

    //        ModelName = request.ModelName.Trim(),

    //        ModelPath = request.ModelPath.Trim(),

    //        Description = request.Description?.Trim(),

    //        ModelMetadata = request.ModelMetadata,

    //        IsActive = true,

    //        CreatedAt = now,

    //        UpdatedAt = now,

    //        DeletedAt = null
    //    };

    //    // Add region-specific information
    //    foreach (var regionRequest in request.Regions)
    //    {
    //        model.ModelRegions.Add(
    //            new ModelRegion
    //            {
    //                ModelId = model.Id,

    //                RegionId = regionRequest.RegionId,

    //                ItemNumber = regionRequest.ItemNumber,

    //                Price = regionRequest.Price,



    //                IsActive = true,

    //                CreatedAt = now,

    //                UpdatedAt = now
    //            });
    //    }

    //    await _modelRepository.AddAsync(model);

    //    return MapToResponse(model);
    //}

    public async Task<ModelResponse> CreateAsync(
    CreateModelRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.ModelId))
        {
            throw new ArgumentException(
                "Model ID is required.");
        }

        if (string.IsNullOrWhiteSpace(request.ModelName))
        {
            throw new ArgumentException(
                "Model name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.ModelPath))
        {
            throw new ArgumentException(
                "Model path is required.");
        }

        if (request.Regions == null ||
            request.Regions.Count == 0)
        {
            throw new ArgumentException(
                "At least one region is required.");
        }

        // Verify Category
        var category =
            await _categoryRepository
                .GetByIdAsync(request.CategoryId);

        if (category == null)
        {
            throw new InvalidOperationException(
                "Category not found.");
        }

        if (!category.IsActive)
        {
            throw new InvalidOperationException(
                "Category is inactive.");
        }

        // -----------------------------
        // Validate Regions
        // -----------------------------

        var duplicateRegion =
            request.Regions
                .GroupBy(x => x.RegionId)
                .Any(g => g.Count() > 1);

        if (duplicateRegion)
        {
            throw new ArgumentException(
                "Duplicate regions are not allowed.");
        }

        foreach (var regionRequest in request.Regions)
        {
            var region =
                await _regionRepository
                    .GetByIdAsync(regionRequest.RegionId);

            if (region == null)
            {
                throw new InvalidOperationException(
                    $"Region {regionRequest.RegionId} not found.");
            }

            if (!region.IsActive)
            {
                throw new InvalidOperationException(
                    $"Region {regionRequest.RegionId} is inactive.");
            }

            if (regionRequest.Price < 0)
            {
                throw new ArgumentException(
                    "Price cannot be negative.");
            }

            if (string.IsNullOrWhiteSpace(regionRequest.ItemNumber))
            {
                throw new ArgumentException(
                    "Item number is required.");
            }
        }

        // -----------------------------
        // Validate Textures
        // -----------------------------

        var textures =
            request.Textures ?? new List<CreateModelTextureRequest>();

        var duplicateTexture =
            textures
                .GroupBy(x => x.TextureId)
                .Any(g => g.Count() > 1);

        if (duplicateTexture)
        {
            throw new ArgumentException(
                "Duplicate textures are not allowed.");
        }

        foreach (var textureRequest in textures)
        {
            var texture =
                await _textureRepository
                    .GetByIdAsync(textureRequest.TextureId);

            if (texture == null)
            {
                throw new InvalidOperationException(
                    $"Texture {textureRequest.TextureId} not found.");
            }

            if (!texture.IsActive)
            {
                throw new InvalidOperationException(
                    $"Texture {textureRequest.TextureId} is inactive.");
            }

            if (string.IsNullOrWhiteSpace(textureRequest.SkuNumber))
            {
                throw new ArgumentException(
                    "SKU number is required for each texture.");
            }
        }

        // -----------------------------
        // Create Model
        // -----------------------------

        var now = DateTime.UtcNow;

        var model = new Model
        {
            Id = Guid.NewGuid(),

            CategoryId = request.CategoryId,

            ModelName = request.ModelName.Trim(),

            ModelPath = request.ModelPath.Trim(),

            Description = request.Description?.Trim(),

            ModelMetadata = request.ModelMetadata,

            IsActive = true,

            CreatedAt = now,

            UpdatedAt = now,

            DeletedAt = null
        };

        // -----------------------------
        // Add Region Information
        // -----------------------------

        foreach (var regionRequest in request.Regions)
        {
            model.ModelRegions.Add(
                new ModelVariantRegion
                {
                    ModelId = model.Id,

                    RegionId = regionRequest.RegionId,

                    ItemNumber = regionRequest.ItemNumber.Trim(),

                    Price = regionRequest.Price,

                    IsActive = true,

                    CreatedAt = now,

                    UpdatedAt = now
                });
        }

        // -----------------------------
        // Add Texture Information
        // -----------------------------

        foreach (var textureRequest in textures)
        {
            model.ModelTextures.Add(
                new ModelVariant
                {
                    ModelId = model.Id,

                    TextureId = textureRequest.TextureId,

                    SkuNumber = textureRequest.SkuNumber.Trim(),

                    ThumbnailPath =
                        string.IsNullOrWhiteSpace(
                            textureRequest.ThumbnailPath)
                            ? null
                            : textureRequest.ThumbnailPath.Trim()
                });
        }

        // -----------------------------
        // Save
        // -----------------------------

        await _modelRepository.AddAsync(model);

        return MapToResponse(model);
    }

    public async Task<ModelResponse?> UpdateAsync(
        Guid id,
        UpdateModelRequest request)
    {
        var model =
            await _modelRepository.GetByIdAsync(id);

        if (model == null)
        {
            return null;
        }

        if (string.IsNullOrWhiteSpace(request.ModelName))
        {
            throw new ArgumentException(
                "Model name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.ModelPath))
        {
            throw new ArgumentException(
                "Model path is required.");
        }

        // Verify Category
        var category =
            await _categoryRepository
                .GetByIdAsync(request.CategoryId);

        if (category == null)
        {
            throw new InvalidOperationException(
                "Category not found.");
        }

        if (!category.IsActive)
        {
            throw new InvalidOperationException(
                "Category is inactive.");
        }

        model.CategoryId = request.CategoryId;

        model.ModelName =
            request.ModelName.Trim();

        model.ModelPath =
            request.ModelPath.Trim();

        model.ModelMetadata =
            request.ModelMetadata;

        model.UpdatedAt = DateTime.UtcNow;

        await _modelRepository.UpdateAsync(model);

        return MapToResponse(model);
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var model =
            await _modelRepository.GetByIdAsync(id);

        if (model == null)
        {
            return false;
        }

        model.IsActive = false;

        model.DeletedAt = DateTime.UtcNow;

        model.UpdatedAt = DateTime.UtcNow;

        await _modelRepository.UpdateAsync(model);

        return true;
    }

    private static ModelResponse MapToResponse(Model model)
    {
        return new ModelResponse
        {
            Id = model.Id,

            CategoryId = model.CategoryId,

            ModelName = model.ModelName,

            ModelPath = model.ModelPath,

            Description = model.Description,

            ModelMetadata = model.ModelMetadata,

            IsActive = model.IsActive,

            CreatedAt = model.CreatedAt,

            UpdatedAt = model.UpdatedAt
        };
    }

    public async Task<List<ModelResponse>> GetByCategoryForUserAsync(
    Guid userId,
    Guid categoryId)
    {
        // Get logged-in user
        var user = await _userRepository.GetByIdAsync(userId);

        if (user == null)
        {
            throw new InvalidOperationException(
                "User not found.");
        }

        if (!user.IsActive)
        {
            throw new InvalidOperationException(
                "User is inactive.");
        }

        // Verify category
        var category =
            await _categoryRepository.GetByIdAsync(categoryId);

        if (category == null)
        {
            throw new InvalidOperationException(
                "Category not found.");
        }

        if (!category.IsActive)
        {
            throw new InvalidOperationException(
                "Category is inactive.");
        }

        // Get models for category + user's region
        var models =
            await _modelRepository
                .GetByCategoryAndRegionAsync(
                    categoryId,
                    user.RegionId);

        return models
            .Select(MapToResponse)
            .ToList();
    }
}