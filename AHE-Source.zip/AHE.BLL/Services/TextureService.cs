﻿using AHE.BLL.DTOs.Textures;
using AHE.BLL.Interfaces;
using AHE.DAL.Entities;
using AHE.DAL.Interfaces.Repositories;

namespace AHE.BLL.Services;

public class TextureService : ITextureService
{
    private readonly ITextureRepository _textureRepository;
    private readonly ICategoryRepository _categoryRepository;

    public TextureService(
        ITextureRepository textureRepository,
        ICategoryRepository categoryRepository)
    {
        _textureRepository = textureRepository;
        _categoryRepository = categoryRepository;
    }

    public async Task<TextureResponse> CreateAsync(
        CreateTextureRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.TextureId))
        {
            throw new ArgumentException(
                "Texture ID is required.");
        }

        if (string.IsNullOrWhiteSpace(request.TextureName))
        {
            throw new ArgumentException(
                "Texture name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.TexturePath))
        {
            throw new ArgumentException(
                "Texture path is required.");
        }

        var now = DateTime.UtcNow;

        var texture = new Texture
        {
            Id = Guid.NewGuid(),

            TextureName = request.TextureName.Trim(),

            TexturePath = request.TexturePath.Trim(),

            TextureMetadata = request.TextureMetadata,

            IsActive = true,

            CreatedAt = now,

            UpdatedAt = now,

            DeletedAt = null
        };

        var createdTexture =
            await _textureRepository.AddAsync(texture);

        return MapToResponse(createdTexture);
    }

    public async Task<List<TextureResponse>> GetAllAsync()
    {
        var textures =
            await _textureRepository.GetAllAsync();

        return textures
            .Select(MapToResponse)
            .ToList();
    }

    public async Task<TextureResponse?> GetByIdAsync(Guid id)
    {
        var texture =
            await _textureRepository.GetByIdAsync(id);

        if (texture == null)
        {
            return null;
        }

        return MapToResponse(texture);
    }

    
    public async Task<TextureResponse?> UpdateAsync(
    Guid id,
    UpdateTextureRequest request)
    {
        var texture =
            await _textureRepository.GetByIdAsync(id);

        if (texture == null)
        {
            return null;
        }

        if (texture.DeletedAt != null)
        {
            throw new InvalidOperationException(
                "Cannot update a deleted texture.");
        }

        if (string.IsNullOrWhiteSpace(request.TextureName))
        {
            throw new ArgumentException(
                "Texture name is required.");
        }

        if (string.IsNullOrWhiteSpace(request.TexturePath))
        {
            throw new ArgumentException(
                "Texture path is required.");
        }

        texture.TextureName =
            request.TextureName.Trim();

        texture.TexturePath =
            request.TexturePath.Trim();

        texture.TextureMetadata =
            request.TextureMetadata;

        texture.IsActive =
            request.IsActive;

        texture.UpdatedAt =
            DateTime.UtcNow;

        await _textureRepository.UpdateAsync(texture);

        return MapToResponse(texture);
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var texture =
            await _textureRepository.GetByIdAsync(id);

        if (texture == null)
        {
            return false;
        }

        if (texture.DeletedAt != null)
        {
            return true;
        }

        texture.DeletedAt = DateTime.UtcNow;
        texture.IsActive = false;
        texture.UpdatedAt = DateTime.UtcNow;

        await _textureRepository.UpdateAsync(texture);

        return true;
    }

    private static TextureResponse MapToResponse(
    Texture texture)
    {
        return new TextureResponse
        {
            Id = texture.Id,

            TextureName = texture.TextureName,

            TexturePath = texture.TexturePath,

            TextureMetadata = texture.TextureMetadata,

            IsActive = texture.IsActive,

            CreatedAt = texture.CreatedAt,

            UpdatedAt = texture.UpdatedAt
        };
    }

}