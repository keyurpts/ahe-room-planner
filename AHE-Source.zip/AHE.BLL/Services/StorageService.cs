﻿using AHE.BLL.DTOs.Storage;
using AHE.BLL.Interfaces;
using AHE.DAL.Interfaces.Repositories;
using AHE.DAL.Entities;
using AHE.DAL.Repositories;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace AHE.BLL.Services
{
    public class StorageService : IStorageService
    {
        private readonly IBlobStorageRepository _blobStorageRepository;
        private readonly IModelRepository _modelRepository;
        private readonly int _sasExpiryMinutes;

        public StorageService(
            IBlobStorageRepository blobStorageRepository,
            IConfiguration configuration,
            IModelRepository modelRepository)
        {
            _blobStorageRepository = blobStorageRepository;
            _modelRepository = modelRepository;

            _sasExpiryMinutes =
            configuration.GetValue<int>(
                "AzureStorage:SasExpiryMinutes");

            if (_sasExpiryMinutes <= 0)
            {
                _sasExpiryMinutes = 15;
            }
        }

        public async Task<bool> TestConnectionAsync(
            CancellationToken cancellationToken = default)
        {
            return await _blobStorageRepository
                .TestConnectionAsync(cancellationToken);
        }

        public async Task<string> UploadAsync(
            Stream stream,
            string fileName,
            string contentType,
            CancellationToken cancellationToken = default)
        {
            if (stream == null || stream.Length == 0)
                throw new ArgumentException("File cannot be empty.");

            if (string.IsNullOrWhiteSpace(fileName))
                throw new ArgumentException("File name is required.");

            return await _blobStorageRepository.UploadAsync(
                stream,
                fileName,
                contentType,
                cancellationToken);
        }

        public async Task<Stream?> DownloadAsync(
            string fileName,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(fileName))
                throw new ArgumentException("File name is required.");

            return await _blobStorageRepository.DownloadAsync(
                fileName,
                cancellationToken);
        }

        public async Task<bool> DeleteAsync(
            string fileName,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(fileName))
                throw new ArgumentException("File name is required.");

            return await _blobStorageRepository.DeleteAsync(
                fileName,
                cancellationToken);
        }

        public async Task<ModelUploadUrlResponse> GenerateUploadUrlAsync(
        Guid modelId,
        CancellationToken cancellationToken = default)
        {
            //var model =
            //    await _modelRepository.GetByIdAsync(
            //        modelId,
            //        cancellationToken);

            var model = await _modelRepository.GetByIdAsync(modelId);

            if (model == null)
            {
                throw new KeyNotFoundException(
                    $"Model with ID '{modelId}' was not found.");
            }

            if (!model.IsActive)
            {
                throw new InvalidOperationException(
                    "The model is not active.");
            }

            var blobPath = BuildModelPath(model);

            const string contentType = "model/gltf-binary";

            var expiresAt =
                DateTimeOffset.UtcNow.AddMinutes(
                    _sasExpiryMinutes);

            var uploadUrl =
                _blobStorageRepository.GenerateUploadSasUrl(
                    blobPath,
                    contentType,
                    _sasExpiryMinutes);

            // Store the path in PostgreSQL.
            model.ModelPath = blobPath;
            model.UpdatedAt = DateTime.UtcNow;

            await _modelRepository.UpdateAsync(
                model);

            return new ModelUploadUrlResponse
            {
                ModelId = model.Id,
                BlobPath = blobPath,
                UploadUrl = uploadUrl.ToString(),
                ExpiresAt = expiresAt
            };
        }

        public async Task<ModelDownloadUrlResponse> GenerateDownloadUrlAsync(
            Guid modelId,
            CancellationToken cancellationToken = default)
        {
            var model =
                await _modelRepository.GetByIdAsync(
                    modelId);

            if (model == null)
            {
                throw new KeyNotFoundException(
                    $"Model with ID '{modelId}' was not found.");
            }

            if (!model.IsActive)
            {
                throw new InvalidOperationException(
                    "The model is not active.");
            }

            if (string.IsNullOrWhiteSpace(model.ModelPath))
            {
                throw new InvalidOperationException(
                    "Model does not have an uploaded asset.");
            }

            var expiresAt =
                DateTimeOffset.UtcNow.AddMinutes(
                    _sasExpiryMinutes);

            var downloadUrl =
                _blobStorageRepository.GenerateDownloadSasUrl(
                    model.ModelPath,
                    _sasExpiryMinutes);

            return new ModelDownloadUrlResponse
            {
                ModelId = model.Id,
                BlobPath = model.ModelPath,
                DownloadUrl = downloadUrl.ToString(),
                ExpiresAt = expiresAt
            };
        }

        private static string BuildModelPath(Model model)
        {
            var categoryId = model.CategoryId.ToString();
            var modelId = model.Id.ToString();

            var modelName =
                model.ModelName
                    .Trim()
                    .Replace("/", "_")
                    .Replace("\\", "_");

            return
                $"models/{categoryId}/{modelId}/{modelName}/model.glb";
        }
    }
}
